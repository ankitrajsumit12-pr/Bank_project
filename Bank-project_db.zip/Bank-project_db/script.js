let currentUser = "";

function createAccount(){

let user=document.getElementById("newUser").value;
let pass=document.getElementById("newPass").value;
let balance=document.getElementById("balance").value;

fetch("http://localhost:3000/createAccount",{

method:"POST",
headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

username:user,
password:pass,
balance:balance

})

})

.then(res=>res.json())

.then(data=>{

alert("Account Created Successfully");

window.location.href="index.html";

});

}

function login(){

let user=document.getElementById("username").value;
let pass=document.getElementById("password").value;

fetch("http://localhost:3000/login",{

method:"POST",
headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

username:user,
password:pass

})

})

.then(res=>res.json())

.then(data=>{

if(data.success){

localStorage.setItem("username",user);

window.location.href="dashboard.html";

}

else

alert("Invalid Login");

});

}

function checkBalance(){

let user=localStorage.getItem("username");

fetch("http://localhost:3000/balance",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({username:user})

})

.then(res=>res.json())

.then(data=>{

document.getElementById("result").innerHTML=

"Balance = ₹"+data.balance;

});

}

function depositMoney(){

let amount=prompt("Enter Deposit Amount");

let user=localStorage.getItem("username");

fetch("http://localhost:3000/deposit",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

username:user,
amount:amount

})

})

.then(res=>res.json())

.then(data=>{

alert("Money Deposited Successfully");

});

}

function withdrawMoney(){

let amount=prompt("Enter Withdraw Amount");

let user=localStorage.getItem("username");

fetch("http://localhost:3000/withdraw",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

username:user,
amount:amount

})

})

.then(res=>res.json())

.then(data=>{

alert("Money Withdrawn Successfully");

});

}

function logout(){

window.location.href="home.html";

} 