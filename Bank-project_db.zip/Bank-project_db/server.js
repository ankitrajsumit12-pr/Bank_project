const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// Serve HTML files from current project folder
// Default route must come BEFORE static middleware
app.get("/", (req, res) => {
    res.sendFile(__dirname + "/home.html");
});

// Then allow access to other files
app.use(express.static(__dirname));
// MongoDB Atlas Connection

mongoose.connect(
"mongodb://ankitcumit:ankitsumit@ac-dhncirs-shard-00-00.ojg9843.mongodb.net:27017,ac-dhncirs-shard-00-01.ojg9843.mongodb.net:27017,ac-dhncirs-shard-00-02.ojg9843.mongodb.net:27017/skybank?ssl=true&replicaSet=atlas-ofs9wp-shard-0&authSource=admin&retryWrites=true&w=majority"
)
.then(()=>console.log("MongoDB Connected Successfully"))
.catch(err=>console.log(err));


// Schema

const UserSchema = new mongoose.Schema({
    username:String,
    password:String,
    balance:Number
});

const User = mongoose.model("User",UserSchema);


// Create Account API

app.post("/createAccount", async(req,res)=>{

    const {username,password,balance} = req.body;

    const newUser = new User({
        username,
        password,
        balance
    });

    await newUser.save();

    res.json({message:"Account Created"});
});
// Login API
app.post("/login", async(req,res)=>{

    const {username,password} = req.body;
    const user = await User.findOne({
        username,
        password
    });

    if(user)
        res.json({success:true});
    else
        res.json({success:false});
});


// Check Balance API

app.post("/balance", async(req,res)=>{

    const {username} = req.body;

    const user = await User.findOne({username});

    res.json({balance:user.balance});
});


// Deposit API

app.post("/deposit", async(req,res)=>{

    const {username,amount} = req.body;

    const user = await User.findOne({username});

    user.balance += Number(amount);

    await user.save();

    res.json({balance:user.balance});
});


// Withdraw API

app.post("/withdraw", async(req,res)=>{

    const {username,amount} = req.body;

    const user = await User.findOne({username});

    if(user.balance >= amount){
        user.balance -= Number(amount);
        await user.save();
        res.json({balance:user.balance});
    }
    else{
        res.json({message:"Insufficient balance"});
    }
});


// Server Start

app.listen(3000,()=>{
    console.log("Server running at:");
    console.log("http://localhost:3000");
});